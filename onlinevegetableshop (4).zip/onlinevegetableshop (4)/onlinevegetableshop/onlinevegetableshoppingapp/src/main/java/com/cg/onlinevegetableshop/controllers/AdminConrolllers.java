package com.cg.onlinevegetableshop.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlinevegetableshop.exceptions.ResourceNotFoundException;
import com.cg.onlinevegetableshop.model.Admin;
import com.cg.onlinevegetableshop.model.User;
import com.cg.onlinevegetableshop.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminConrolllers {
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/getAdmin/{id}")
	public Admin getAdmin(@PathVariable int id) {
		return adminService.viewAdmin(id);
	}
	
	@PostMapping("/insertAdmin")
	public User createAdmin(@RequestBody Admin admin) {
		return adminService.createAdmin(admin);
	}
	
	
	@PutMapping("/updateAdmin")
	public Admin updateAdmin(@RequestBody Admin admin) {
		return adminService.updateAdmin(admin);
	}
	
	@RequestMapping(value="/deleteAdmin/{id}",method=RequestMethod.DELETE)
	public Map<String,Boolean> deleteAdmin(@PathVariable int adminId) throws ResourceNotFoundException{
		return adminService.deleteAdmin(adminId);
	}
}
