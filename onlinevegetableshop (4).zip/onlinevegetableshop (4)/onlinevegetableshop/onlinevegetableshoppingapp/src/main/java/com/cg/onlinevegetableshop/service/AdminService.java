package com.cg.onlinevegetableshop.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.onlinevegetableshop.model.Admin;
import com.cg.onlinevegetableshop.model.User;
import com.cg.onlinevegetableshop.repositories.AdminRepository;
import com.cg.onlinevegetableshop.repositories.LoginRepository;
import com.cg.onlinevegetableshop.exceptions.ResourceNotFoundException;



@Repository
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private LoginRepository loginRepository;
	
	public Admin viewAdmin(int adminId) {
		return adminRepository.getOne(adminId);
	}
	
	public User createAdmin(Admin admin) {
		User user = new User();
		user.setPassword(admin.getPassword());
		user.setRole("admin");
		adminRepository.saveAndFlush(admin);
		return loginRepository.save(user);
	}
	
	public Admin updateAdmin(Admin admin) {
		Admin existingAdmin=adminRepository.getOne(admin.getAdminId());
		BeanUtils.copyProperties(admin, existingAdmin);
		return adminRepository.save(existingAdmin);
	}
	
    public Map<String, Boolean> deleteAdmin(int adminId)
    		throws ResourceNotFoundException {
        Admin admin = adminRepository.getOne(adminId);
        if(admin==null) {
        	throw new ResourceNotFoundException("No User Found");
        }
        
        adminRepository.delete(admin);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }
	
}
