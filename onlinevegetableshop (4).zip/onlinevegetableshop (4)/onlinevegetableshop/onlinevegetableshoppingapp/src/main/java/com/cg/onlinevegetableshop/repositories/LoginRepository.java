package com.cg.onlinevegetableshop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.onlinevegetableshop.model.User;


public interface LoginRepository extends JpaRepository<User, Integer>{
	
}
