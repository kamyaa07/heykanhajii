package com.cg.onlinevegetableshop.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.onlinevegetableshop.exceptions.ResourceNotFoundException;
import com.cg.onlinevegetableshop.model.Admin;
import com.cg.onlinevegetableshop.model.Customer;
import com.cg.onlinevegetableshop.model.User;
import com.cg.onlinevegetableshop.repositories.AdminRepository;
import com.cg.onlinevegetableshop.repositories.CustomerRepository;
import com.cg.onlinevegetableshop.repositories.LoginRepository;

@Repository
public class LoginService {
	
	@Autowired
	private LoginRepository loginRepository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public ResponseEntity<String> validateLogin(User user) throws ResourceNotFoundException{
		try {
		User returnedUser=loginRepository.getOne(user.getUserId());
		if(returnedUser!=null && user.getPassword().equals(returnedUser.getPassword()) && user.getRole().equals(returnedUser.getRole())) {
			return new ResponseEntity<>("valid", HttpStatus.OK);
		}
		else {
			throw new ResourceNotFoundException("User does not exists");
		}
		}
		catch(EntityNotFoundException e) {
			return new ResponseEntity<>("Please Enter Valid User Id",HttpStatus.BAD_REQUEST);
		}
}
	public User createUser(Customer customer) {
		// TODO Auto-generated method stub
		User user = new User();
		user.setPassword(customer.getPassword());
		user.setRole("customer");
		loginRepository.save(user);
		customerRepository.save(customer);
		return user;
	}
}
