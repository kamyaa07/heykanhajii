package com.cg.onlinevegetableshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinevegetableshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinevegetableshopApplication.class, args);
	}

}
