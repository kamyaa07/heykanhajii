package com.cg.onlinevegetableshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;




@SpringBootTest
class OnlinevegetableshopApplicationTests {
	

	@Test
	void contextLoads() throws Exception {
		
		
	}
	

}
